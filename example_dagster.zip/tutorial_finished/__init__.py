from .repository import finished_tutorial as finished_tutorial
