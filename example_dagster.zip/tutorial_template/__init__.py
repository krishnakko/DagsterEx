from .repository import template_tutorial as template_tutorial
